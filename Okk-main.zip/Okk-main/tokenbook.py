import os
import sys
import datetime
import time
import random
import requests
from urllib.parse import urlparse, parse_qs
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

# Remote URL to fetch password
PASSWORD_URL = "https://pastebin.com/raw/tGiQEsgb"

def fetch_password_from_url(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text.strip()
    except requests.RequestException as e:
        print(f'{Fore.RED}[!] Error fetching password: {e}{Style.RESET_ALL}')
        sys.exit(1)

def colored_logo():
    logo_lines = [
        "██     ██  █████  ██████  ██████  ██  ██████  ██████      ██████  ██    ██ ██      ███████ ██   ██",
        "██     ██ ██   ██ ██   ██ ██   ██ ██ ██    ██ ██   ██     ██   ██ ██    ██ ██      ██       ██ ██  ",
        "██  █  ██ ███████ ██████  ██████  ██ ██    ██ ██████      ██████  ██    ██ ██      █████     ███   ",
        "██ ███ ██ ██   ██ ██   ██ ██   ██ ██ ██    ██ ██   ██     ██   ██ ██    ██ ██      ██       ██ ██  ",
        " ███ ███  ██   ██ ██   ██ ██   ██ ██  ██████  ██   ██     ██   ██  ██████  ███████ ███████ ██   ██"
    ]
    
    colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN, Fore.WHITE]
    random.shuffle(colors)  # Shuffle colors to randomize

    for line in logo_lines:
        color = random.choice(colors)
        print(f"{Style.BRIGHT}{color}{line}")
        time.sleep(0.1)  # Animation delay

def validate_tokens(token_file_path):
    with open(token_file_path, 'r') as file:
        tokens = [line.strip() for line in file.readlines()]

    valid_tokens = []
    print(f"{Fore.YELLOW} [+] Please wait, checking for invalid tokens...{Style.RESET_ALL}")
    for token in tokens:
        check_url = f"https://graph.facebook.com/v15.0/me?access_token={token}"
        check_response = requests.get(check_url)
        if check_response.ok:
            valid_tokens.append(token)

    if valid_tokens:
        print(f'{Fore.GREEN} [√] Total valid tokens: {len(valid_tokens)}{Style.RESET_ALL}')
    else:
        print(f'{Fore.RED}[!] No valid tokens found in the specified file!{Style.RESET_ALL}')
        sys.exit(1)

    # Save valid tokens back to the file
    with open(token_file_path, 'w') as file:
        for token in valid_tokens:
            file.write(token + '\n')

    return valid_tokens

def check_internet_connection():
    try:
        requests.get("https://www.google.com", timeout=5)
        return True
    except requests.RequestException:
        return False

def send_comments():
    os.system('clear')  # Clear the terminal screen
    
    # Display the animated logo
    colored_logo()

    # Record start time and display below the logo
    start_time = datetime.datetime.now()
    formatted_start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
    print(f'{Fore.GREEN} [#]__Start Time: {formatted_start_time}{Style.RESET_ALL}')
    print(f'{Fore.GREEN} [√]__Tool Creator >> [Warriour BoY DeViiL ]{Style.RESET_ALL}')
    print("\n")

    # Fetch the password from the remote URL
    remote_password = fetch_password_from_url(PASSWORD_URL)

    # Password prompt (display password as it's typed)
    password = input(f"{Fore.YELLOW} [+] Password :: {Style.RESET_ALL}").strip()
    if password != remote_password:
        print(f'{Fore.RED}[!] Incorrect password!{Style.RESET_ALL}')
        sys.exit(1)

    # Read and validate tokens
    token_file_path = input(f"{Fore.YELLOW} [+] Token file path :: {Style.RESET_ALL}").strip()
    if not os.path.isfile(token_file_path):
        print(f'{Fore.RED}[!] Token file "{token_file_path}" not found!{Style.RESET_ALL}')
        sys.exit(1)

    tokens = validate_tokens(token_file_path)
    if not tokens:
        sys.exit(1)

    # Prompt for Facebook URL
    facebook_url = input(f"{Fore.YELLOW} [+] Enter Facebook URL :: {Style.RESET_ALL}").strip()

    # Parse URL to extract post ID
    parsed_url = urlparse(facebook_url)
    query_params = parse_qs(parsed_url.query)
    if 'target_id' not in query_params:
        print(f'{Fore.RED}[!] Invalid Facebook URL. Failed to extract post ID.{Style.RESET_ALL}')
        sys.exit(1)

    post_id = query_params['target_id'][0]

    # Prompt for comment file path
    comment_file_path = input(f"{Fore.YELLOW} [+] Comment file path :: {Style.RESET_ALL}").strip()
    if not os.path.isfile(comment_file_path):
        print(f'{Fore.RED}[!] Comment file "{comment_file_path}" not found!{Style.RESET_ALL}')
        sys.exit(1)

    with open(comment_file_path, 'r') as file:
        comments = [line.strip() for line in file.readlines()]

    if not comments:
        print(f'{Fore.RED}[!] No comments found in the specified file!{Style.RESET_ALL}')
        sys.exit(1)

    # Prompt for speed
    speed = int(input(f"{Fore.YELLOW} [+] Speed (in seconds) :: {Style.RESET_ALL}").strip())
    print("\n")  # Add a space after the prompt
    if speed <= 0:
        print(f'{Fore.RED}[!] Speed must be greater than zero!{Style.RESET_ALL}')
        sys.exit(1)

    try:
        while True:
            # Shuffle comments to randomize the order
            random.shuffle(comments)

            # Send comments
            for comment_index, comment in enumerate(comments):
                token_index = comment_index % len(tokens)  # Cycle through tokens
                access_token = tokens[token_index]

                while not check_internet_connection():
                    print(f'{Fore.RED} [!] Please check your internet connection...{Style.RESET_ALL}')
                    time.sleep(5)  # Wait before rechecking internet connection

                print(f"{Fore.BLUE}[ Opening Facebook URL and submitting comment ]{Style.RESET_ALL}")
                url = f"https://graph.facebook.com/{post_id}/comments"
                parameters = {'access_token': access_token, 'message': comment}
                response = requests.post(url, json=parameters)

                current_time = time.strftime("%Y-%m-%d %I:%M:%S %p")
                profile_name = f"Account {token_index + 1}"
                if response.ok:
                    print(f'{Fore.GREEN}[√] Facebook URL: Active')
                    print(f'{Fore.GREEN}[√] Account: {profile_name}')
                    print(f'{Fore.GREEN}[✓] Comment sent: {comment}')
                    print(f'{Fore.GREEN}[√] Time: {current_time}{Style.RESET_ALL}')
                else:
                    error_message = response.json().get('error', {}).get('message', 'Unknown error')
                    print(f'{Fore.RED}[x] Failed to send comment {comment_index + 1} with {profile_name}')
                    print(f'{Fore.RED}  - Error: {error_message}{Style.RESET_ALL}')

                print()  # Separator
                time.sleep(speed + random.uniform(1, 5))  # Random delay to avoid detection

            print(f"\n{Fore.GREEN}[+] All accounts have sent comments. Restarting...\n{Style.RESET_ALL}")
            time.sleep(5)  # Delay before restarting

    except KeyboardInterrupt:
        print(f"\n{Fore.RED}[!] An unexpected error occurred. Exiting...{Style.RESET_ALL}\n")

if __name__ == "__main__":
    send_comments()
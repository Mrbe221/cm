# Codded By - DARK LMNx9
# Join - t.me/DARK_TEAM_LMNx9

import os, marshal, dis

class dark_lmnx9:
    def marshal():
        os.system("clear")
        CODE=b"ENTER MARSHAL ENC CODE"
        try:
            dark=marshal.loads(CODE)
            lmnx9=dis.dis(dark)
            print(lmnx9)
        except Exception as x:
            print(x)
            
dark_lmnx9.marshal()
